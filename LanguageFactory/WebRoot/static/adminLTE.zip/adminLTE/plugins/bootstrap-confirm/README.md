confirm-bootstrap
=================

The confirm modal made with Twitter Bootstrap

See the [documentation][1] for usage.

Branch [master][4] follows [boostrap3][2] and branch [bootstrap2][5] follows [boostrap2][3].

[1]: http://maxailloud.github.io/confirm-bootstrap/.
[2]: http://getbootstrap.com/
[3]: http://getbootstrap.com/2.3.2/
[4]: https://github.com/maxailloud/confirm-bootstrap
[5]: https://github.com/maxailloud/confirm-bootstrap/tree/bootstrap2