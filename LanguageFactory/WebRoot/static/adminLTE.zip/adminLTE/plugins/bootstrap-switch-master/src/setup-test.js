import $ from 'jquery';

global.jQuery = $;
global.$ = global.jQuery;
